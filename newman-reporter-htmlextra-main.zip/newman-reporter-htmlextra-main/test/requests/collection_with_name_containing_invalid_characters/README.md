
| File Name                         | Collection Name |
|--|--|
| invalid1.postman_collection.json  | C:\             |
| invalid2.postman_collection.json  | test|test       |
| invalid3.postman_collection.json  | test?test       |
| invalid4.postman_collection.json  | test<test       |
| invalid5.postman_collection.json  | test>test       |
| invalid6.postman_collection.json  | test"test       |
| invalid8.postman_collection.json  | test/test       |
| invalid9.postman_collection.json  | test:test       |
| invalid10.postman_collection.json | test*test       |
| valid1.postman_collection.json    | TEST TEST       |
| valid2.postman_collection.json    | TEST &TEST      |
| valid3.postman_collection.json    | TEST_TEST       |
| valid4.postman_collection.json    | test\test       |
| valid5.postman_collection.json    | test.test       |
| valid6.postman_collection.json    | test test test  |
| valid7.postman_collection.json    | test^test test  |

